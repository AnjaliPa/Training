


import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.hellospring.controller.HomeController;

import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.springframework.web.servlet.ModelAndView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.Assert;


public class HomeControllerTest {




@Autowired
Model model;

@Test
public void test_Fetch() {
	HomeController homeController =  new HomeController();

	
	ModelAndView modelView = new ModelAndView("home");
	String s = homeController.home();
	modelView =  homeController.home2("anjali");
	System.out.println(modelView);
	Assert.assertEquals("",s);
	Assert.assertNotNull(modelView);
	Assert.assertEquals(modelView.getViewName(),"home");
	Assert.assertTrue(modelView.getModel().containsValue("anjali"));

}


}