package com.hellospring.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController

public class HomeController {
	
	@RequestMapping("/")
	public String home() {
		

		return "Please add myapp in URL to test!!!";
	}
	
	
	@RequestMapping("/myapp")
	public ModelAndView home2(@RequestParam(required = false, value = "name") String name) {
		ModelAndView modelView = new ModelAndView("home");
		
		modelView.addObject("myname", name);

		return modelView;
	}

}
